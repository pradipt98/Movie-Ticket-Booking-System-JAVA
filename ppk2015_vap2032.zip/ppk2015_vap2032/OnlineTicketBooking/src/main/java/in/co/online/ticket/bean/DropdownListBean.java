package in.co.online.ticket.bean;


public interface DropdownListBean
{
	public String getKey();

	public String getValue();
}
