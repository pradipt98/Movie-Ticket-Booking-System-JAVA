package in.co.online.ticket.exception;


public class RecordNotFoundException extends Exception
{

	public RecordNotFoundException(String msg) {
		super(msg);

	}
}
