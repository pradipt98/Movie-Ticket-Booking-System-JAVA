package in.co.online.ticket.exception;



public class ApplicationException  extends Exception
{
	
	public ApplicationException(String msg) {
		super(msg);
	}
}
