package in.co.online.ticket.exception;


public class DatabaseException  extends Exception
{
	
   public DatabaseException(String msg) {
       super(msg);
   }
}

